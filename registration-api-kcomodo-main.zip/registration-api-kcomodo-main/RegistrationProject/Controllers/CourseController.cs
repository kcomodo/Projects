using Microsoft.AspNetCore.Mvc;
using CourseRegisteration.Models;
using CourseRegisteration.Services;
using CourseRegisteration.Repository;
namespace CourseRegisteration.Controllers{

[ApiController]
[Route("/courses")]
public class CoursesController : ControllerBase
{
    public ICourseServices _courseServices;
    public ICourseRepository _courseRepository;
    
    public CoursesController(ICourseServices courseServices)
    {
      _courseServices = courseServices;
    }
    
    
    //endpoint 1
    [HttpGet]
    public IActionResult getCourses()
    {
        try{
        IEnumerable<Course> list = _courseServices.getCourses();
        if(list != null)return Ok(list);
        else return BadRequest();
        }catch(Exception e){
          return StatusCode(500, "Internal server error");
        }
  
    }

    [HttpGet("/coregoals")]
    public IActionResult getCoreGoal()
    {
        try{
        IEnumerable<CoreGoal> list = _courseServices.GetCoreGoals();
        if(list != null)return Ok(list);
        else return BadRequest();
        }catch(Exception e){
          return StatusCode(500, "Internal server error");
        }
  
    }
    //endpoint 2
    /*
    [HttpGet("{name}", Name = "GetCourse")]
    public IActionResult GetCourseByName(string name){
      IEnumerable<Course> list = _courseServices.getCourses();
      foreach(Course c in list){
        if (c.Name.Equals(name)){
          return Ok(c);
        }
      }
      return BadRequest();
    }
    */
     [HttpGet("{name}", Name = "GetCourseByName")]
    public IActionResult GetCourseByName(string name){
      try{
        Course c = _courseServices.GetCourseByName(name);
        if(c!=null)return Ok(c);
        else return BadRequest();
      }
      catch(Exception e){
        return StatusCode(500, "Internal server error");
      }
    }
    /*
    [HttpGet("/coregoals/{id}", Name = "GetCoreGoalById")]
    public IActionResult GetCoreGoalById(string Id){
      try{
        CoreGoal c = _courseServices.GetCoreGoalById(Id);
        if(c!=null)return Ok(c);
        else return BadRequest();
      }
      catch(Exception e){
        return StatusCode(500, "Internal server error");
      }
    }
    */
    [HttpGet("/coregoals/{id}", Name = "GetGoalById")]
    public IActionResult GetCoreGoalWithCoursesById(string Id){
      try{
        CoreGoal c = _courseServices.GetCoreGoalWithCoursesById(Id);
        if(c!=null)return Ok(c);
        else return BadRequest();
      }
      catch(Exception e){
        return StatusCode(500, "Internal server error");
      }
    }
    
    [HttpGet("/coregoals/{id}/courses")]
    public IActionResult GetCoursesForCoreGoalById(string Id){
      
        IEnumerable<Course> c = _courseServices.GetCoursesForCoreGoalById(Id);
        return Ok(c);

      
    }
  
      //endpoint 3
      /*
     [HttpGet("search/")]
    public IActionResult getCourseByDepartment(string department){
      IEnumerable<Course> list = _courseServices.getCourses();
      foreach(Course d in list){
        
        if (d.Departments.Equals(department)){
          return Ok(d);
        }
      }
      return BadRequest();
    }
    */
    //endpoint 4
    /*
    [HttpPost]
    public IActionResult AddNewCourse(Course name){
        try{
          List<Course> list = _courseServices.getCourses();
          list.Add(name);
             return CreatedAtRoute("GetCourses", new {name = name.Name}, name);
        }catch(Exception e){
            return StatusCode(500);
        }
       
    }
    */
      [HttpPost]
    public IActionResult AddNewCourse(Course c){
        try{
          Course returnCourse = _courseServices.InsertCourse(c);
          List<Course> list = _courseServices.getCourses();
         
             return CreatedAtRoute("GetCourseByName", new {name = returnCourse.Name}, returnCourse);
        }catch(Exception e){
            return StatusCode(500);
        }
       
    }
    [HttpPost("/coregoals/")]
    public IActionResult AddNewCoreGoal(CoreGoal c){
        try{
          CoreGoal returnCourse = _courseServices.InsertCoreGoal(c);
          List<Course> list = _courseServices.getCourses();
         
             return CreatedAtRoute("GetGoalById", new {id = returnCourse.Id}, returnCourse);
        }catch(Exception e){
            return StatusCode(500);
        }
       
    }

          
        
    /*
    //endpoint 5
    [HttpPut("{name}")]
    public IActionResult UpdateCourse(string name,Course courseIn){
        try{
        
          IEnumerable<Course> list = _courseServices.getCourses();
          foreach(Course d in list){
            if(d.Name.Equals(name)){
            d.Name=courseIn.Name;
            //d.Departments=courseIn.Departments;
            d.Title=courseIn.Title;
            d.Credits=courseIn.Credits;
            d.Description=courseIn.Description;
            return NoContent();
            }
          }
             return BadRequest();
        }catch(Exception e){
            return StatusCode(500);
        }
       
    }
    */
     [HttpPut("{name}")]
    public IActionResult UpdateCourse(string name,Course courseIn){
     
        
          _courseServices.UpdateCourse(name, courseIn);
            return NoContent();
     
       
    }
    [HttpPut("/coregoals/{id}")]
    public IActionResult UpdateCoreGoal(string Id,CoreGoal modifiedGoal){
     
        
          _courseServices.UpdateCoreGoal(Id, modifiedGoal);
            return NoContent();
     
       
    }
    [HttpPut("/coregoals/{id}/courses")]
    public IActionResult AddCourseToCoreGoal(string Id,Course newCourse){
     
        
          _courseServices.AddCoursetoCoreGoal(Id, newCourse);
            return NoContent();
     
       
    }
     [HttpDelete("{name}")]
    public IActionResult DeleteCourse(string name){
        _courseServices.DeleteCourse(name);
        return NoContent();

    }
         [HttpDelete("/coregoals/{id}")]
    public IActionResult DeleteCoreGoal(string Id){
        _courseServices.DeleteCoreGoal(Id);
        return NoContent();

    }
    /*
    //endpoint 6
     [HttpDelete("{name}")]
    public IActionResult DeleteCourse(string name){
        try{
          
        
          List<Course> list = _courseServices.getCourses();
          foreach(Course d in list){
            if(d.Name.Equals(name)){
              list.Remove(d);
            return NoContent();
            }
          }
             return BadRequest();
        }catch(Exception e){
            return StatusCode(500);
        }
       
    }
 
*/
    //endpoint 7
    [HttpGet("{name}/{goal}")]
    public IActionResult getCoreGoal(string name)
    {
        IEnumerable<CoreGoal> list = _courseServices.getCoreGoalByCourse();
        foreach(CoreGoal c in list){
          if (c != null){
          return Ok(c);
        }
      }
      return BadRequest();
    }
    //endpoint 8
    [HttpGet("{name}/offerings/")]
    public IActionResult getCourseOfferingBySemester(string name,string semester)
    {
        IEnumerable<CourseOffering> list = _courseServices.getCourseOfferingsBySemester(name, semester);
        //return NoContent();
        foreach(CourseOffering c in list){
          if (c != null){
          return Ok(c);
        }
      }
      return BadRequest();
    }
 
 
 
 
      
  
    

}
}
using System;
using System.Collections.Generic;
using System.Text;
namespace CourseRegisteration.Models
{
    public class CourseDepartments:IComparable<CourseDepartments>
    {
        public string departmentID{get;set;}

           public override String ToString() {
            return $"{departmentID}\n";

        }
            public int CompareTo(CourseDepartments other) {
            return this.departmentID.CompareTo(other.departmentID);
        }
    }
 
}
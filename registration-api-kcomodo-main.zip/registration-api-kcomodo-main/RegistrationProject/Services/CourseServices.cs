using System;
using System.Collections.Generic;
using CourseRegisteration.Models;
using CourseRegisteration.Repository;
using System.Linq;
namespace CourseRegisteration.Services
{
    public class CourseServices : ICourseServices
    {
       
        private readonly ICourseRepository _repo;
        public CourseServices(ICourseRepository courseRepo){
         _repo = courseRepo;
        }

        //As a student, I want to search for course offerings that meet core goals 
        // so that I can register easily for courses that meet my program requirements
        
         public List<CourseOffering> getOfferingsByGoalIdAndSemester(String theGoalId, String semester) {
          //finish this method during the tutorial 
          //use the repo to get the data from the database (data store)
         List<CoreGoal> theGoals = _repo.Goals;
         List<CourseOffering> theOfferings = _repo.Offerings;
         
         //Complete any other required functionality/business logic to satisfy the requirement
         CoreGoal theGoal=null;
         foreach(CoreGoal cg in theGoals) {
            if(cg.Id.Equals(theGoalId)) {
            theGoal=cg; break;
 
         }
      }
       if(theGoal==null) throw new Exception("Didn't find the goal");
      //search list of courses, then for each course, search offerings
      List<CourseOffering> courseOfferingsThatMeetGoal = new List<CourseOffering>();
            
      foreach(CourseOffering c in theOfferings) {
         if(c.Semester.Equals(semester) ) 
      {
         courseOfferingsThatMeetGoal.Add(c);
      }
 
   }
      return courseOfferingsThatMeetGoal;
        }
        
      public List<Course> getCourses(){ //Return all courses available
         List<Course> theCourses = _repo.GetAll().ToList<Course>();
        return theCourses;
      }
      public List<CoreGoal> GetCoreGoals(){
         List<CoreGoal> theCoreGoal = _repo.GetAllCoreGoals().ToList<CoreGoal>();
         return theCoreGoal;
      }
      public Course GetCourseByName(string name){
         Course c = _repo.GetCourseByName(name);
         return c;
      }
      public CoreGoal GetCoreGoalById(string Id){
         CoreGoal c = _repo.GetCoreGoalById(Id);
         return c;
      }
      
      public List<Course> GetCoursesForCoreGoalById(string Id){
         List<Course> theCourses = _repo.GetCoursesForCoreGoalById(Id).ToList<Course>();
        return theCourses;

      }
      public CoreGoal GetCoreGoalWithCoursesById(string Id){
         CoreGoal c = _repo.GetCoreGoalWithCoursesById(Id);
         return c;
      }
      public Course InsertCourse(Course newCourse){
         return _repo.InsertCourse(newCourse);
         
      }
      public CoreGoal InsertCoreGoal(CoreGoal newCoreGoal){
         return _repo.InsertCoreGoal(newCoreGoal);
         
      }
      public void UpdateCourse(string name, Course courseIn){
           _repo.UpdateCourse(name,courseIn);

        }
        public void UpdateCoreGoal(string Id, CoreGoal modifiedGoal){
           _repo.UpdateCoreGoal(Id,modifiedGoal);

        }
        public void AddCoursetoCoreGoal(string Id,Course newCourse){
          _repo.AddCoursetoCoreGoal(Id,newCourse);
        }
        public void DeleteCourse(string name){
         _repo.DeleteCourse(name);
        }
         public void DeleteCoreGoal(string Id){
            _repo.DeleteCoreGoal(Id);
         }
        public List<CourseOffering> getCourseOfferingsBySemester(string name,string semester)
        {   
            List<CourseOffering> courseBySemester = _repo.Offerings;
            List<CourseOffering> displaySemesterAndSemester = new List<CourseOffering>();    
            foreach(CourseOffering c in courseBySemester){
                  if(c.Semester.Equals(semester)){
                     displaySemesterAndSemester.Add(c);
               }
               }    return displaySemesterAndSemester;
            //List<CourseOffering> courseBySemester = _repo.Offerings;
            //return courseBySemester;
   
        }
        public List<CoreGoal> getCoreGoalByCourse()
        {   
            List<CoreGoal> coreGoalByCourses = _repo.Goals;            
            return coreGoalByCourses;
   
        }
   
      

        public List<CourseOffering> getCourseOfferingsBySemesterAndDept(String semester, String department)
        {
            
            List<CourseOffering> courseBySemester = _repo.Offerings;
            List<CourseOffering> displaySemesterAndSemester = new List<CourseOffering>();    
            foreach(CourseOffering c in courseBySemester){
                  if(c.Semester.Equals(semester) && c.Departments.Equals(department)){
                     displaySemesterAndSemester.Add(c);
                  
               }
               }    return displaySemesterAndSemester;
               
               
               /*
               if(c.Semester.Equals(semester) && (c.departments.Equals(department)){
                 
               } */
            }




        /*if(c.Semester.Equals(semester) && (c.departments.Equals(department)){

        }*/
    }

            
        
            }
            
            
        







        //Add more service functions here, as needed, for the project

        /* As a student, I want to see all available courses so that I know what my options are */

        /* As a student, I want to see all course offerings by semester, so that I can choose from what's
           available to register for next semester */

        /* As a student I want to see all course offerings by semester and department so that I can 
        choose major courses to register for */

        /* As a student I want to see all courses that meet a core goal, so that I can plan out
           my courses over the next few semesters and choose core courses that make sense for me */

        /* As a student I want to find a course that meets two different core goals, so that I can
        "feed two birds with one seed" (save time by taking one class that will fulfill two 
          requirements */

        /* As a freshman adviser, I want to see all the core goals which do not have any course offerings 
           for a given semester, so that I can work with departments to get some courses offered
           that students can take to meet those goals */


   


using System;
using System.Collections.Generic;
using CourseRegisteration.Models;
using CourseRegisteration.Services;
using MySql.Data.MySqlClient;
namespace CourseRegisteration.Repository
{
    public interface ICourseRepository{
        //obselete, delete soon
        List<Course> Courses {get;set;}
        List<CoreGoal> Goals {get;set;}
        List<CourseOffering> Offerings {get;set;}
        //List<CourseDepartments> Departments{get;set;}


        public Course GetCourseByName(string name);
        public CoreGoal GetCoreGoalById(string Id);
        public CoreGoal GetCoreGoalWithCoursesById(string Id);
        public IEnumerable<Course> GetCoursesForCoreGoalById(string Id);
        public void UpdateCoreGoal(string Id,CoreGoal modifiedGoal);
        public IEnumerable<Course> GetAll();
        public IEnumerable<CoreGoal> GetAllCoreGoals();
        public Course InsertCourse(Course newCourse);
        public CoreGoal InsertCoreGoal(CoreGoal newGoal);
        public void AddCoursetoCoreGoal(string Id,Course newCourse);
        
        public void UpdateCourse(string name, Course courseIn);
        public void DeleteCourse(string name);
         public void DeleteCoreGoal(string Id);
        
    }
    public interface IOperationSingleton : ICourseRepository { }
    public class CourseRepository:ICourseRepository, IOperationSingleton {
        public List<Course> Courses {get;set;}
        // public List<CourseDepartments> Departments{get;set;}
        public List<CoreGoal> Goals {get;set;}
        public List<CourseOffering> Offerings {get;set;}
        private MySqlConnection _connection;
       
        public CourseRepository(){
            string connectionString = "server=localhost;userid=csci330user;password=csci330pass;database=courseregistration";
            _connection = new MySqlConnection(connectionString);
            _connection.Open();
        }
        ~CourseRepository(){
            _connection.Close();
        }

        //get all object from courses in mysql
        public IEnumerable<Course> GetAll(){
            var statement = "Select * from Course";
            var command = new MySqlCommand(statement, _connection);
            var results = command.ExecuteReader();

            List<Course> newList = new List<Course>(25);
            while(results.Read()){
                Course c = new Course{
                    Name = (string)results[0],
                    Title = (string)results[1],
                    Credits = (double)results[2],
                    Description = (string)results[3]
                };
                newList.Add(c);
            }
            results.Close();
            return newList;
        }
         public IEnumerable<Course> GetCoursesForCoreGoalById(string Id){
            var statement = "Select * from Course where Name=@newName";
            var command = new MySqlCommand(statement, _connection);
            

            List<Course> newList = new List<Course>(25);
            if(Id == "CG1"){
            command.Parameters.AddWithValue("@newName", "ARTD 501");
            var results = command.ExecuteReader();
             while(results.Read()){
                Course c = new Course{
                    Name = (string)results[0],
                    Title = (string)results[1],
                    Credits = (double)results[2],
                    Description = (string)results[3]
                };
                newList.Add(c);
                }
                results.Close();
            }else if(Id == "CG2"){
            command.Parameters.AddWithValue("@newName", "ARTS 101");
            var results = command.ExecuteReader();
             while(results.Read()){
                Course c = new Course{
                    Name = (string)results[0],
                    Title = (string)results[1],
                    Credits = (double)results[2],
                    Description = (string)results[3]
                };
                newList.Add(c);
                }
                results.Close();
            }else if(Id == "CG3"){
            command.Parameters.AddWithValue("@newName", "ENGL 301");
            var results = command.ExecuteReader();
             while(results.Read()){
                Course c = new Course{
                    Name = (string)results[0],
                    Title = (string)results[1],
                    Credits = (double)results[2],
                    Description = (string)results[3]
                };
                newList.Add(c);
                }
                results.Close();
            }
            
           
            
            
            return newList;
            
    
           
    }
        public IEnumerable<CoreGoal> GetAllCoreGoals(){
            var statement = "Select * from CoreGoals";
            var command = new MySqlCommand(statement, _connection);
            var results = command.ExecuteReader();

            List<CoreGoal> newList = new List<CoreGoal>(25);
            while(results.Read()){
                CoreGoal c = new CoreGoal{
                    Id = (string)results[0],
                    CourseName = (string)results[1],
                    Description = (string)results[2]
                };
                newList.Add(c);
            }
            
            results.Close();
            return newList;
        }
     
        public Course GetCourseByName(string name){
            var statement = "Select * from Course where Name=@newName";
            var command = new MySqlCommand(statement, _connection);
            command.Parameters.AddWithValue("@newName", name);
            var results = command.ExecuteReader();
            List<Course> newList = new List<Course>(25);
            if(results.Read()){
                Course c = new Course{
                    Name = (string)results[0],
                    Title = (string)results[1],
                    Credits = (double)results[2],
                    Description = (string)results[3]
                };
               results.Close();
               return c;
            }
            results.Close();
            return null;
            
        }
        public CoreGoal GetCoreGoalById(string Id){
            var statement = "Select * from CoreGoals where Id=@newId";

            var command = new MySqlCommand(statement, _connection);
            command.Parameters.AddWithValue("@newId", Id);
            var results = command.ExecuteReader();
            List<CoreGoal> newList = new List<CoreGoal>(25);
            if(results.Read()){
                CoreGoal c = new CoreGoal{
                    Id = (string)results[0],
                    CourseName = (string)results[1],
                    Description = (string)results[2]
                };
               results.Close();
               return c;
            }
            results.Close();
            return null;
            
        }
        public CoreGoal GetCoreGoalWithCoursesById(string Id){
            var statement = "Select * from CoreGoalCourses where GoalId=@newId";

            var command = new MySqlCommand(statement, _connection);
            command.Parameters.AddWithValue("@newId", Id);
            var results = command.ExecuteReader();
            List<CoreGoal> newList = new List<CoreGoal>(25);
            if(results.Read()){
                CoreGoal c = new CoreGoal{
                    Id = (string)results[0],
                    CourseName = (string)results[1]
                };
               results.Close();
               return c;
            }
            results.Close();
            return null;
            
        }
       
            public Course InsertCourse(Course newCourse){
             var statement = "Insert into Course (Name, Title, Credits, Description) values (@newName, @newTitle, @newCredit, @newDescription)";

            var command = new MySqlCommand(statement, _connection);
            command.Parameters.AddWithValue("@newName", newCourse.Name);
            command.Parameters.AddWithValue("@newTitle", newCourse.Title);
            command.Parameters.AddWithValue("@newCredit", newCourse.Credits);
            command.Parameters.AddWithValue("@newDescription", newCourse.Description);
            int result = command.ExecuteNonQuery();
            if(result == 1){
                return newCourse;
            }else{
                return null;
            }
        }
        public CoreGoal InsertCoreGoal(CoreGoal newGoal){
             var statement = "Insert into CoreGoals (Id, Name, Description) values (@newId, @newName, @newDescription)";

            var command = new MySqlCommand(statement, _connection);
            command.Parameters.AddWithValue("@newId", newGoal.Id);
            command.Parameters.AddWithValue("@newName", newGoal.CourseName);
            command.Parameters.AddWithValue("@newDescription", newGoal.Description);
            int result = command.ExecuteNonQuery();
            if(result == 1){
                return newGoal;
            }else{
                return null;
            }
        }
        public void UpdateCourse(string name,Course courseIn){
        var statement = "Update Course Set Name=@newName, Title=@newTitle, Credits=@newCredit, Description=@newDescription Where Name = @updateName";
        var command = new MySqlCommand(statement, _connection);
        command.Parameters.AddWithValue("@newName", courseIn.Name);
        command.Parameters.AddWithValue("@newTitle", courseIn.Title);
        command.Parameters.AddWithValue("@newCredit", courseIn.Credits);
        command.Parameters.AddWithValue("@newDescription", courseIn.Description);
        command.Parameters.AddWithValue("@updateName", name);

        int result = command.ExecuteNonQuery();
      
    } 
     public void UpdateCoreGoal(string Id,CoreGoal modifiedGoal){
        var statement = "Update CoreGoals Set Id=@newId, Name=@newName, Description=@newDescription Where Id = @updateId";
        var command = new MySqlCommand(statement, _connection);
        command.Parameters.AddWithValue("@newId", modifiedGoal.Id);
        command.Parameters.AddWithValue("@newName", modifiedGoal.CourseName);
        command.Parameters.AddWithValue("@newDescription", modifiedGoal.Description);
        command.Parameters.AddWithValue("@updateId", Id);

        int result = command.ExecuteNonQuery();
      
    }   
     public void AddCoursetoCoreGoal(string Id,Course newCourse){
        var statement = "Update Course Set Name=@newName, Title=@newTitle, Credits = @newCredits, Description=@newDescription Where Name = @updateName";
        var command = new MySqlCommand(statement, _connection);
        command.Parameters.AddWithValue("@newName", newCourse.Name);
        command.Parameters.AddWithValue("@newTitle", newCourse.Title);
        command.Parameters.AddWithValue("@newCredits", newCourse.Credits);
        command.Parameters.AddWithValue("@newDescription", newCourse.Description);
        command.Parameters.AddWithValue("@updateName", Id);

        int result = command.ExecuteNonQuery();
      
    }   
      
    public void DeleteCourse(string name){
        var statement = "Select * from Course";
            var command = new MySqlCommand(statement, _connection);
            var results = command.ExecuteReader();

            List<Course> newList = new List<Course>(25);
            while(results.Read()){
                Course c = new Course{
                    Name = (string)results[0],
                    Title = (string)results[1],
                    Credits = (double)results[2],
                    Description = (string)results[3]
                };
                newList.Add(c);
            }
            results.Close();
        
            foreach(Course c in newList){
                if(c.Name.Equals(name)){
                    newList.Remove(c);
                    return;
    }

    }
}
 public void DeleteCoreGoal(string Id){
        var statement = "Select * from CoreGoals";
            var command = new MySqlCommand(statement, _connection);
            var results = command.ExecuteReader();

            List<CoreGoal> newList = new List<CoreGoal>(25);
            while(results.Read()){
                CoreGoal c = new CoreGoal{
                    Id = (string)results[0],
                    CourseName = (string)results[1],
                    Description = (string)results[2]
                };
                newList.Add(c);
            }
            results.Close();
        
            foreach(CoreGoal c in newList){
                if(c.Id.Equals(Id)){
                    newList.Remove(c);
                    return;
    }

    }
}
       //Add more data as needed 
        /*
        public CourseRepository() {
            Courses = new List<Course>();
            Departments = new List<CourseDepartments>();
            Goals=new List<CoreGoal>();
            Offerings=new List<CourseOffering>();
            

            CourseDepartments d1 = new CourseDepartments(){
                departmentID = "CSCI"
            
            };
            CourseDepartments d2 = new CourseDepartments(){
                departmentID = "Digital Culture and Design"
           
            };
            CourseDepartments d3 = new CourseDepartments(){
                departmentID = "Communication, Media and Culture"
              
            };
       
            Departments.Add(d1);
            Departments.Add(d2);
            Departments.Add(d3);

            Course c1 = new Course() {
                Name="ARTD 105",
                Departments="CSCI",
                Title="graphic design",
                Credits=3.0,
                Description="graphic design descr"
              

            };
            Course c2 = new Course() {
                Name="ARTS 101",
                Departments = "ARTS",
                Title="art studio",
                Credits=3.0,
                Description="studio descr"
               

            };
            Course c3 = new Course() {
                Name="STAT 201",
                Departments = "Math",
                Title="stats",
                Credits=4.0,
                Description="stats descr",
               

            };
            Course c4 = new Course() {
                Name="ENGL 302",
                Departments = "Communication, Media and Culture",
                Title="English as a Communication language",
                Credits=4.0,
                Description="communication descr"
                

            };
            Courses.Add(c1);
            Courses.Add(c2);
            Courses.Add(c3);
            Courses.Add(c4);
            
            CourseOffering co1 = new CourseOffering() {
                Departments = "CSCI",
                TheCourse=c1,
                Section="01",
                Semester="Fall 2021",
                

            };

            CourseOffering co2 = new CourseOffering() {
                Departments = "MATH",
                TheCourse=c2,
                Section="D1",
                Semester="Fall 2020",
                

            };
            
            CourseOffering co3 = new CourseOffering() {
                Departments = "Communication, Media and Culture",
                TheCourse=c2,
                Section="01",
                Semester="Spring 2022",
                

            };
            Offerings.Add(co1);
            Offerings.Add(co2);
            Offerings.Add(co3);
            CoreGoal cg1 = new CoreGoal() {
                Id="CG1",
                CoreName="Artistic Expression",
                Description="Desc for artistic expression",
                Courses = new List<Course>() {
                    c1
                }

            };
            CoreGoal cg2 = new CoreGoal() {
                Id="CG2",
                CoreName="Quantitative Literacy",
                Description="Desc for quantitative literacy",
                Courses = new List<Course>() {
                    c2,c3
                }

            };
            CoreGoal cg3 = new CoreGoal() {
                Id="CG3",
                CoreName="Effective Communication",
                Description="Desc for communication",
                Courses = new List<Course>() {
                    c4,c3
                }

            };
            Goals.Add(cg1);
            Goals.Add(cg2);
            Goals.Add(cg3);

        }//end constructor
        */
        /*
        public List<CourseOffering> getOfferingsByGoalIdAndSemester(String theGoalId, String semester) {
            CoreGoal theGoal=null;
            foreach(CoreGoal cg in Goals) {
                if(cg.Id.Equals(theGoalId)) {
                    theGoal=cg; break;

                }
            }
            if(theGoal==null) throw new Exception("Didn't find the goal");
            //search list of courses, then for each course, search offerings
            List<CourseOffering> courseOfferingsThatMeetGoal = new List<CourseOffering>();
            
            foreach(CourseOffering c in Offerings) {
                if(c.Semester.Equals(semester) 
                    && theGoal.Courses.Contains(c.TheCourse) ) 
                    {courseOfferingsThatMeetGoal.Add(c);}



            }//end for
            return courseOfferingsThatMeetGoal;
    
        }
        */
       
    
     

    }
   
    
}
